<?php
$mod_strings['LBL_LOGINAUDIT_GROUP'] = 'Login Audit';
$mod_strings['LBL_LOGINAUDIT_ADMIN'] = 'Login Audit';
$mod_strings['LBL_LOGINAUDIT_GROUP_DESCRIPTION'] = 'Searchable list of system authentication activity';
$mod_strings['LBL_LOGINAUDIT_DESCRIPTION'] = 'Tracks logins and logouts on the system';
?>
